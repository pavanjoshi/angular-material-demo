import { Component, Input, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { StarRatingColor } from './star-rating/star-rating.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Add to Shopping Cart';
  
  rating: number = 3;
  starCount: number = 5;
  starColor: StarRatingColor = StarRatingColor.accent;
  starColorP: StarRatingColor = StarRatingColor.primary;
  starColorW: StarRatingColor = StarRatingColor.warn;

  totalQty: number = 0;

  qty: number = 1;

  constructor(private _sb: MatSnackBar){    
  }

  ngOnInit(): void {    
  }

  onRatingChanged(rating) {
    console.log(rating);
    this.rating = rating;
  }

  wishlistProduct($event) {
    this._sb.open('Upcoming feature!', '', {
      duration: 3000
    });
  }

  shareProduct($event) {
    this._sb.open('Upcoming feature!', '', {
      duration: 3000
    });
  }

  addToCart($event) {
    this.totalQty += this.qty;
    this._sb.open('Upcoming feature!', '', {
      duration: 3000
    });
  }
}
